"""Тесты построения графа, циклов и обратных зависимостей."""
import unittest

from depgraph.errors import PackageNotFoundError
from depgraph.graph import (build_graph, graph_edges, has_cycles,
                            reverse_index)

DIAMOND = {"A": ["B", "C"], "B": ["D"], "C": ["D"], "D": []}
CYCLE = {"A": ["B"], "B": ["C"], "C": ["A"]}


class GraphTests(unittest.TestCase):
    """Проверки алгоритмов над графом."""

    def test_bfs_order_and_shared_dependency(self):
        """Общая зависимость D попадает в граф один раз."""
        graph = build_graph(DIAMOND, "A")
        self.assertEqual(list(graph), ["A", "B", "C", "D"])
        self.assertEqual(len(graph_edges(graph)), 4)

    def test_cycle_terminates(self):
        """Цикл не приводит к зависанию, обратное ребро сохраняется."""
        graph = build_graph(CYCLE, "A")
        self.assertEqual(list(graph), ["A", "B", "C"])
        self.assertIn(("C", "A"), graph_edges(graph))
        self.assertTrue(has_cycles(graph))

    def test_no_cycle(self):
        """В ромбе циклов нет."""
        self.assertFalse(has_cycles(build_graph(DIAMOND, "A")))

    def test_self_dependency(self):
        """Зависимость пакета от самого себя считается циклом."""
        graph = build_graph({"H": ["H"]}, "H")
        self.assertTrue(has_cycles(graph))

    def test_deep_chain_without_recursion(self):
        """Цепочка из 5000 пакетов не вызывает переполнение стека."""
        size = 5000
        index = {str(n): [str(n + 1)] for n in range(size)}
        index[str(size)] = []
        self.assertEqual(len(build_graph(index, "0")), size + 1)

    def test_max_depth(self):
        """Глубина 1 даёт только прямые зависимости."""
        graph = build_graph(DIAMOND, "A", max_depth=1)
        self.assertEqual(graph, {"A": ["B", "C"], "B": [], "C": []})

    def test_unknown_dependency_is_leaf(self):
        """Зависимость, которой нет в индексе, становится листом."""
        graph = build_graph({"A": ["virtual"]}, "A")
        self.assertEqual(graph["virtual"], [])

    def test_missing_root(self):
        """Отсутствующий пакет даёт PackageNotFoundError."""
        with self.assertRaises(PackageNotFoundError):
            build_graph(DIAMOND, "Z")

    def test_reverse_dependencies(self):
        """Обратные зависимости D: B и C, затем транзитивно A."""
        graph = build_graph(reverse_index(DIAMOND), "D")
        self.assertEqual(list(graph), ["D", "B", "C", "A"])

    def test_flip_edges(self):
        """Режим flip возвращает исходное направление стрелок."""
        graph = build_graph(reverse_index(DIAMOND), "D")
        self.assertIn(("B", "D"), graph_edges(graph, flip=True))
