"""Тесты чтения тестового репозитория."""
import unittest

from depgraph.errors import RepositoryError
from depgraph.testrepo import parse_test_repo


class TestRepoTests(unittest.TestCase):
    """Проверки формата файла с графом."""

    def test_valid(self):
        """Корректное описание с комментариями и запятыми."""
        index = parse_test_repo("# c\nA: B, C\nB:\n")
        self.assertEqual(index, {"A": ["B", "C"], "B": []})

    def test_lowercase_rejected(self):
        """Строчные имена запрещены."""
        with self.assertRaises(RepositoryError):
            parse_test_repo("a: B\n")

    def test_missing_colon(self):
        """Строка без двоеточия — ошибка формата."""
        with self.assertRaises(RepositoryError):
            parse_test_repo("A B\n")

    def test_duplicate(self):
        """Повторное описание пакета — ошибка."""
        with self.assertRaises(RepositoryError):
            parse_test_repo("A: B\nA: C\n")
