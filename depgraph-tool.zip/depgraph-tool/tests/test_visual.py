"""Тесты D2, ASCII-дерева и встроенного SVG."""
import unittest
import xml.etree.ElementTree as ElementTree

from depgraph.ascii_tree import render_tree
from depgraph.d2 import quote, to_d2
from depgraph.graph import build_graph
from depgraph.svg_builtin import compute_levels, render_svg

DIAMOND = {"A": ["B", "C"], "B": ["D"], "C": ["D"], "D": []}
CYCLE = {"A": ["B"], "B": ["A"]}


class VisualTests(unittest.TestCase):
    """Проверки визуализации."""

    def test_d2_edges(self):
        """В D2 есть рёбра и выделенный корень."""
        text = to_d2(build_graph(DIAMOND, "A"), "A")
        self.assertIn('"A" -> "B"', text)
        self.assertIn('"C" -> "D"', text)
        self.assertIn("style.fill", text)

    def test_d2_flip(self):
        """При flip стрелки меняют направление."""
        text = to_d2(build_graph({"A": ["B"], "B": []}, "A"), "A", True)
        self.assertIn('"B" -> "A"', text)

    def test_d2_quote(self):
        """Имена со специальными символами экранируются."""
        self.assertEqual(quote("libstdc++6"), '"libstdc++6"')

    def test_ascii_tree_diamond(self):
        """Общий узел D раскрывается один раз."""
        tree = render_tree(build_graph(DIAMOND, "A"), "A")
        self.assertEqual(tree.splitlines(), [
            "A", "|-- B", "|   `-- D", "`-- C", "    `-- D"])

    def test_ascii_tree_cycle(self):
        """Цикл помечается и не раскрывается бесконечно."""
        tree = render_tree(build_graph(CYCLE, "A"), "A")
        self.assertEqual(tree.splitlines(), ["A", "`-- B", "    `-- A (...)"])

    def test_levels(self):
        """Узлы раскладываются по расстоянию от корня."""
        levels = compute_levels(build_graph(DIAMOND, "A"), "A")
        self.assertEqual(levels, [["A"], ["B", "C"], ["D"]])

    def test_svg_is_valid_xml(self):
        """Встроенный SVG корректный XML, содержит все узлы."""
        svg = render_svg(build_graph(CYCLE, "A"), "A")
        root = ElementTree.fromstring(svg)
        self.assertTrue(root.tag.endswith("svg"))
        self.assertEqual(svg.count("<text"), 2)

    def test_svg_escapes_names(self):
        """Спецсимволы в подписях экранируются."""
        svg = render_svg({"a&b": []}, "a&b")
        ElementTree.fromstring(svg)
        self.assertIn("a&amp;b", svg)
