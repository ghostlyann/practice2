"""Тесты разбора индекса пакетов Ubuntu."""
import gzip
import os
import tempfile
import unittest

from depgraph.apt import (clean_dependency, index_urls, load_index,
                          parse_dependency_field, parse_packages)
from depgraph.errors import RepositoryError

SAMPLE = """Package: app
Version: 1.0
Depends: libc6 (>= 2.34), liba | libb, libz:any, libx [amd64]
Pre-Depends: dpkg (>= 1.19)
Description: demo
 continuation line

Package: liba
Depends: libc6,
 libz
"""


class AptTests(unittest.TestCase):
    """Проверки чтения формата Packages."""

    def test_clean_dependency_removes_decorations(self):
        """Версия, архитектура и квалификатор :any отбрасываются."""
        self.assertEqual(clean_dependency(" libc6 (>= 2.34) "), "libc6")
        self.assertEqual(clean_dependency("python3:any"), "python3")
        self.assertEqual(clean_dependency("libx [amd64]"), "libx")

    def test_alternatives_take_first(self):
        """Из альтернатив a | b берётся первая."""
        self.assertEqual(parse_dependency_field("a | b, c"), ["a", "c"])

    def test_duplicates_removed(self):
        """Повторы убираются, порядок сохраняется."""
        self.assertEqual(parse_dependency_field("a, b, a"), ["a", "b"])

    def test_parse_packages(self):
        """Pre-Depends идёт перед Depends, описание игнорируется."""
        index = parse_packages(SAMPLE)
        self.assertEqual(index["app"],
                         ["dpkg", "libc6", "liba", "libz", "libx"])
        self.assertEqual(index["liba"], ["libc6", "libz"])

    def test_index_urls(self):
        """URL индекса строится из базы, выпуска, компонента и архитектуры."""
        urls = index_urls("http://x/ubuntu/", "noble", ["main", "universe"],
                          "amd64")
        self.assertEqual(urls[1], "http://x/ubuntu/dists/noble/universe/"
                                  "binary-amd64/Packages.gz")
        direct = "file:///tmp/Packages"
        self.assertEqual(index_urls(direct, "a", ["b"], "c"), [direct])

    def test_load_index_from_gz_file(self):
        """Индекс читается из сжатого файла по URL file://."""
        with tempfile.TemporaryDirectory() as folder:
            path = os.path.join(folder, "Packages.gz")
            with gzip.open(path, "wt", encoding="utf-8") as handle:
                handle.write(SAMPLE)
            index = load_index("file://" + path, "r", ["main"], "amd64")
        self.assertIn("app", index)

    def test_missing_file_is_error(self):
        """Недоступный адрес даёт RepositoryError."""
        with self.assertRaises(RepositoryError):
            load_index("file:///no/such/Packages.gz", "r", ["main"], "a")
