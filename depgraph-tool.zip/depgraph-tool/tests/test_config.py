"""Тесты разбора и проверки параметров."""
import os
import tempfile
import unittest

from depgraph.config import format_config, parse_args, validate_config
from depgraph.errors import ConfigError


class ConfigTests(unittest.TestCase):
    """Проверки обработки ошибок всех параметров."""

    def setUp(self):
        """Создаёт временный файл тестового репозитория."""
        self.folder = tempfile.TemporaryDirectory()
        self.repo = os.path.join(self.folder.name, "repo.txt")
        with open(self.repo, "w", encoding="utf-8") as handle:
            handle.write("A:\n")
        self.output = os.path.join(self.folder.name, "g.svg")

    def tearDown(self):
        """Удаляет временную папку."""
        self.folder.cleanup()

    def check(self, *args):
        """Разбирает и проверяет аргументы."""
        validate_config(parse_args(list(args)))

    def good(self):
        """Корректный набор аргументов."""
        return ["-p", "A", "-r", self.repo, "-t", "-o", self.output]

    def test_valid(self):
        """Корректные параметры принимаются."""
        self.check(*self.good())

    def test_missing_required(self):
        """Без обязательных параметров — ConfigError."""
        with self.assertRaises(ConfigError):
            self.check("-p", "A")

    def test_bad_test_package_name(self):
        """В тестовом режиме имя должно быть заглавным."""
        with self.assertRaises(ConfigError):
            self.check("-p", "a", "-r", self.repo, "-t", "-o", self.output)

    def test_bad_apt_package_name(self):
        """Имя пакета apt не может содержать пробел."""
        with self.assertRaises(ConfigError):
            self.check("-p", "bad name", "-r", "http://x", "-o", self.output)

    def test_missing_test_file(self):
        """Несуществующий файл тестового репозитория."""
        with self.assertRaises(ConfigError):
            self.check("-p", "A", "-r", "/no/file", "-t", "-o", self.output)

    def test_url_in_test_mode(self):
        """URL в тестовом режиме запрещён."""
        with self.assertRaises(ConfigError):
            self.check("-p", "A", "-r", "http://x", "-t", "-o", self.output)

    def test_path_without_test_mode(self):
        """Путь к файлу без --test-mode запрещён."""
        with self.assertRaises(ConfigError):
            self.check("-p", "bash", "-r", self.repo, "-o", self.output)

    def test_bad_output(self):
        """Расширение не .svg и несуществующая папка."""
        with self.assertRaises(ConfigError):
            self.check("-p", "A", "-r", self.repo, "-t", "-o", "g.png")
        with self.assertRaises(ConfigError):
            self.check("-p", "A", "-r", self.repo, "-t", "-o", "/no/dir/g.svg")

    def test_bad_depth(self):
        """Глубина должна быть положительным целым."""
        with self.assertRaises(ConfigError):
            self.check(*self.good(), "--max-depth", "0")
        with self.assertRaises(ConfigError):
            self.check(*self.good(), "--max-depth", "abc")

    def test_format_config(self):
        """Вывод в формате ключ=значение."""
        text = format_config(parse_args(self.good()))
        self.assertIn("package=A", text)
        self.assertIn("test_mode=True", text)
