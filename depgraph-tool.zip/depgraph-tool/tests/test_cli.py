"""Сквозные тесты приложения."""
import contextlib
import io
import os
import tempfile
import unittest

from depgraph.cli import EXIT_ERROR, EXIT_OK, main

EXAMPLES = os.path.join(os.path.dirname(__file__), os.pardir, "examples")


class CliTests(unittest.TestCase):
    """Запуск main() на тестовых репозиториях."""

    def run_main(self, *args):
        """Запускает main, возвращает код, stdout и stderr."""
        out, err = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            code = main(list(args))
        return code, out.getvalue(), err.getvalue()

    def example(self, name):
        """Путь к примеру репозитория."""
        return os.path.join(EXAMPLES, name)

    def test_cycle_tree_and_files(self):
        """Цикл: дерево выведено, D2 и SVG сохранены."""
        with tempfile.TemporaryDirectory() as folder:
            svg = os.path.join(folder, "out.svg")
            code, out, _ = self.run_main(
                "-p", "A", "-r", self.example("cycle.txt"), "-t",
                "-a", "-o", svg)
            self.assertEqual(code, EXIT_OK)
            self.assertIn("Циклические зависимости: есть", out)
            self.assertIn("(...)", out)
            self.assertTrue(os.path.getsize(svg))
            self.assertTrue(os.path.exists(os.path.join(folder, "out.d2")))

    def test_reverse(self):
        """Обратные зависимости D в ромбе."""
        with tempfile.TemporaryDirectory() as folder:
            code, out, _ = self.run_main(
                "-p", "D", "-r", self.example("simple.txt"), "-t",
                "--reverse", "-o", os.path.join(folder, "r.svg"))
        self.assertEqual(code, EXIT_OK)
        self.assertIn("Обратные зависимости (3)", out)

    def test_apt_file_url(self):
        """Индекс Ubuntu из локального файла через file://."""
        url = "file://" + os.path.abspath(self.example("Packages"))
        with tempfile.TemporaryDirectory() as folder:
            code, out, _ = self.run_main(
                "-p", "app", "-r", url, "-o", os.path.join(folder, "a.svg"))
        self.assertEqual(code, EXIT_OK)
        self.assertIn("libgcc-s1", out)

    def test_unknown_package(self):
        """Неизвестный пакет: код ошибки и сообщение."""
        code, _, err = self.run_main(
            "-p", "Z", "-r", self.example("simple.txt"), "-t")
        self.assertEqual(code, EXIT_ERROR)
        self.assertIn("не найден", err)

    def test_bad_arguments(self):
        """Неверные параметры дают код ошибки, а не traceback."""
        code, _, err = self.run_main("-p", "A")
        self.assertEqual(code, EXIT_ERROR)
        self.assertIn("Ошибка", err)
