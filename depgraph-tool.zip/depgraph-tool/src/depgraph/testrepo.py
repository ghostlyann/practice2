"""Тестовый репозиторий: граф из текстового файла, имена A, B, C..."""
from __future__ import annotations

import re
from typing import List, Tuple

from .errors import RepositoryError
from .graph import Index

NAME_RE = re.compile(r"[A-Z]+")


def _check_name(name: str, number: int) -> None:
    """Проверяет, что имя состоит из заглавных латинских букв."""
    if not NAME_RE.fullmatch(name):
        raise RepositoryError(
            f"строка {number}: имя '{name}' должно состоять из "
            "заглавных латинских букв")


def _parse_line(line: str, number: int) -> Tuple[str, List[str]]:
    """Разбирает строку вида 'A: B C'."""
    name, separator, rest = line.partition(":")
    if not separator:
        raise RepositoryError(f"строка {number}: ожидается формат 'A: B C'")
    name = name.strip()
    _check_name(name, number)
    dependencies: List[str] = []
    for dependency in rest.replace(",", " ").split():
        _check_name(dependency, number)
        if dependency not in dependencies:
            dependencies.append(dependency)
    return name, dependencies


def parse_test_repo(text: str) -> Index:
    """Разбирает описание графа; пустые строки и #-комментарии игнорируются."""
    index: Index = {}
    for number, raw in enumerate(text.splitlines(), start=1):
        line = raw.split("#")[0].strip()
        if not line:
            continue
        name, dependencies = _parse_line(line, number)
        if name in index:
            raise RepositoryError(
                f"строка {number}: пакет {name} описан повторно")
        index[name] = dependencies
    return index


def load_test_repo(path: str) -> Index:
    """Читает файл тестового репозитория."""
    try:
        with open(path, encoding="utf-8") as handle:
            text = handle.read()
    except (OSError, UnicodeDecodeError) as error:
        raise RepositoryError(
            f"не удалось прочитать {path}: {error}") from error
    index = parse_test_repo(text)
    if not index:
        raise RepositoryError(f"файл {path} не содержит пакетов")
    return index
