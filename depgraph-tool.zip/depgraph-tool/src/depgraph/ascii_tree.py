"""Вывод графа зависимостей в виде ASCII-дерева."""
from __future__ import annotations

from typing import List, Tuple

from .graph import Graph

BRANCH = "|-- "
LAST_BRANCH = "`-- "
PIPE = "|   "
SPACE = "    "
REPEAT_MARK = " (...)"

Item = Tuple[str, str, bool]


def _children(graph: Graph, name: str, prefix: str) -> List[Item]:
    """Возвращает дочерние узлы в виде (имя, префикс, последний ли)."""
    names = graph.get(name, [])
    last_index = len(names) - 1
    return [(child, prefix, position == last_index)
            for position, child in enumerate(names)]


def render_tree(graph: Graph, root: str) -> str:
    """Строит ASCII-дерево без рекурсии.

    Уже раскрытый узел повторно не раскрывается и помечается (...),
    поэтому общие зависимости и циклы не приводят к бесконечному выводу.
    """
    lines = [root]
    expanded = {root}
    stack = list(reversed(_children(graph, root, "")))
    while stack:
        name, prefix, is_last = stack.pop()
        lines.append(prefix + (LAST_BRANCH if is_last else BRANCH) + name)
        if name in expanded:
            if graph.get(name):
                lines[-1] += REPEAT_MARK
            continue
        expanded.add(name)
        child_prefix = prefix + (SPACE if is_last else PIPE)
        stack.extend(reversed(_children(graph, name, child_prefix)))
    return "\n".join(lines)
