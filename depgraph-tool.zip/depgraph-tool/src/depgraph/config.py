"""Параметры командной строки: описание, разбор, проверка и вывод."""
from __future__ import annotations

import argparse
import os
import re
from dataclasses import asdict, dataclass
from typing import List, Optional, Tuple

from .errors import ConfigError

DEFAULT_OUTPUT = "graph.svg"
DEFAULT_RELEASE = "noble"
DEFAULT_COMPONENTS = "main"
DEFAULT_ARCH = "amd64"
SVG_SUFFIX = ".svg"
MIN_DEPTH = 1
URL_PREFIXES = ("http://", "https://", "file://")
TEST_NAME_RE = re.compile(r"[A-Z]+")
APT_NAME_RE = re.compile(r"[a-z0-9][a-z0-9+.\-]*")
WORD_RE = re.compile(r"[a-z0-9\-]+")


@dataclass(frozen=True)
class Config:
    """Все настраиваемые пользователем параметры."""

    package: str
    repo: str
    test_mode: bool
    output: str
    ascii_tree: bool
    reverse: bool
    max_depth: Optional[int]
    release: str
    components: Tuple[str, ...]
    arch: str
    show_config: bool


class _Parser(argparse.ArgumentParser):
    """Парсер, сообщающий об ошибках исключением, а не выходом."""

    def error(self, message: str):
        """Превращает ошибку argparse в ConfigError."""
        raise ConfigError(message)


def _add_main_options(parser: argparse.ArgumentParser) -> None:
    """Добавляет основные параметры анализа."""
    parser.add_argument(
        "-p", "--package", required=True,
        help="имя анализируемого пакета")
    parser.add_argument(
        "-r", "--repo", required=True,
        help="URL репозитория или путь к файлу тестового репозитория")
    parser.add_argument(
        "-o", "--output", default=DEFAULT_OUTPUT,
        help="имя файла с изображением графа (.svg)")


def _add_mode_options(parser: argparse.ArgumentParser) -> None:
    """Добавляет параметры режимов работы."""
    parser.add_argument(
        "-t", "--test-mode", action="store_true",
        help="режим тестового репозитория (пакеты A, B, C...)")
    parser.add_argument(
        "-a", "--ascii-tree", action="store_true",
        help="вывести зависимости в виде ASCII-дерева")
    parser.add_argument(
        "--reverse", action="store_true",
        help="показать обратные зависимости (кто зависит от пакета)")
    parser.add_argument(
        "--max-depth", type=int, default=None,
        help="ограничить глубину обхода графа")
    parser.add_argument(
        "--show-config", action="store_true",
        help="вывести параметры в формате ключ=значение")


def _add_apt_options(parser: argparse.ArgumentParser) -> None:
    """Добавляет параметры выбора индекса пакетов Ubuntu."""
    parser.add_argument(
        "--release", default=DEFAULT_RELEASE,
        help="выпуск Ubuntu, например noble (по умолчанию noble)")
    parser.add_argument(
        "--components", default=DEFAULT_COMPONENTS,
        help="компоненты через запятую, например main,universe")
    parser.add_argument(
        "--arch", default=DEFAULT_ARCH,
        help="архитектура (по умолчанию amd64)")


def build_parser() -> argparse.ArgumentParser:
    """Создаёт разборщик аргументов командной строки."""
    parser = _Parser(
        prog="depgraph",
        description="Визуализация графа зависимостей пакетов Ubuntu (apt)")
    _add_main_options(parser)
    _add_mode_options(parser)
    _add_apt_options(parser)
    return parser


def parse_args(argv: List[str]) -> Config:
    """Разбирает аргументы и возвращает конфигурацию."""
    namespace = build_parser().parse_args(argv)
    parts = namespace.components.split(",")
    components = tuple(part.strip() for part in parts if part.strip())
    return Config(
        package=namespace.package.strip(),
        repo=namespace.repo.strip(),
        test_mode=namespace.test_mode,
        output=namespace.output,
        ascii_tree=namespace.ascii_tree,
        reverse=namespace.reverse,
        max_depth=namespace.max_depth,
        release=namespace.release,
        components=components,
        arch=namespace.arch,
        show_config=namespace.show_config,
    )


def _check_package(package: str, test_mode: bool) -> None:
    """Проверяет имя пакета для выбранного режима."""
    pattern = TEST_NAME_RE if test_mode else APT_NAME_RE
    if not pattern.fullmatch(package):
        hint = ("заглавные латинские буквы" if test_mode
                else "имя пакета Debian: a-z, 0-9, + - .")
        raise ConfigError(
            f"недопустимое имя пакета '{package}', ожидается: {hint}")


def _check_test_repo_path(path: str, is_url: bool) -> None:
    """Проверяет путь к файлу тестового репозитория."""
    if is_url:
        raise ConfigError(
            "в режиме тестирования вместо URL нужен путь к файлу")
    if not os.path.isfile(path):
        raise ConfigError(f"файл тестового репозитория не найден: {path}")


def _check_repo(repo: str, test_mode: bool) -> None:
    """Проверяет URL репозитория или путь к тестовому файлу."""
    is_url = repo.startswith(URL_PREFIXES)
    if test_mode:
        _check_test_repo_path(repo, is_url)
    elif not is_url:
        raise ConfigError(
            f"'{repo}' не похоже на URL (http://, https://, file://); "
            "для пути к файлу включите --test-mode")


def _check_output(output: str) -> None:
    """Проверяет имя файла изображения."""
    if not output.lower().endswith(SVG_SUFFIX):
        raise ConfigError("файл изображения должен иметь расширение .svg")
    if os.path.isdir(output):
        raise ConfigError(f"'{output}' является папкой, нужен файл")
    folder = os.path.dirname(os.path.abspath(output))
    if not os.path.isdir(folder):
        raise ConfigError(f"папка для сохранения не существует: {folder}")


def _check_depth(max_depth: Optional[int]) -> None:
    """Проверяет ограничение глубины."""
    if max_depth is not None and max_depth < MIN_DEPTH:
        raise ConfigError("--max-depth должен быть целым числом >= 1")


def _check_apt_words(config: Config) -> None:
    """Проверяет выпуск, компоненты и архитектуру."""
    if not config.components:
        raise ConfigError("не указан ни один компонент (--components)")
    words = [config.release, config.arch, *config.components]
    for word in words:
        if not WORD_RE.fullmatch(word):
            raise ConfigError(f"недопустимое значение '{word}'")


def validate_config(config: Config) -> None:
    """Проверяет все параметры, при ошибке бросает ConfigError."""
    _check_package(config.package, config.test_mode)
    _check_repo(config.repo, config.test_mode)
    _check_output(config.output)
    _check_depth(config.max_depth)
    _check_apt_words(config)


def format_config(config: Config) -> str:
    """Возвращает параметры в формате ключ=значение."""
    lines = []
    for key, value in asdict(config).items():
        if isinstance(value, tuple):
            value = ",".join(value)
        lines.append(f"{key}={value}")
    return "\n".join(lines)
