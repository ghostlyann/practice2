"""Исключения приложения: тексты сообщений предназначены пользователю."""


class DepGraphError(Exception):
    """Базовая ошибка приложения."""


class ConfigError(DepGraphError):
    """Некорректные параметры командной строки."""


class RepositoryError(DepGraphError):
    """Репозиторий недоступен или имеет неверный формат."""


class PackageNotFoundError(DepGraphError):
    """Пакет отсутствует в репозитории."""


class OutputError(DepGraphError):
    """Не удалось сохранить результат."""
