"""Интерфейс командной строки: связывает все этапы работы."""
from __future__ import annotations

import os
import sys
from typing import List, Optional

from .apt import load_index
from .ascii_tree import render_tree
from .config import Config, format_config, parse_args, validate_config
from .d2 import render_svg_with_d2, to_d2
from .errors import DepGraphError
from .files import write_text
from .graph import Graph, Index, build_graph, graph_edges, has_cycles
from .graph import reverse_index
from .svg_builtin import render_svg
from .testrepo import load_test_repo

EXIT_OK = 0
EXIT_ERROR = 1


def load_dependency_index(config: Config) -> Index:
    """Загружает индекс из тестового файла или из репозитория Ubuntu."""
    if config.test_mode:
        return load_test_repo(config.repo)
    return load_index(config.repo, config.release, config.components,
                      config.arch)


def describe_graph(graph: Graph, config: Config) -> str:
    """Краткая сводка по построенному графу."""
    kind = "обратные" if config.reverse else "прямые и транзитивные"
    cycles = "есть" if has_cycles(graph) else "нет"
    return "\n".join([
        f"Пакет: {config.package}",
        f"Зависимости: {kind}",
        f"Пакетов в графе: {len(graph)}",
        f"Связей: {len(graph_edges(graph))}",
        f"Циклические зависимости: {cycles}",
    ])


def print_dependencies(graph: Graph, config: Config) -> None:
    """Выводит ASCII-дерево или плоский список зависимостей."""
    if config.ascii_tree:
        print(render_tree(graph, config.package))
        return
    title = "Обратные зависимости" if config.reverse else "Зависимости"
    print(f"{title} ({len(graph) - 1}):")
    for name in graph:
        if name != config.package:
            print(f"  {name}")


def save_visualization(graph: Graph, config: Config) -> None:
    """Сохраняет текст D2 и изображение SVG."""
    d2_path = os.path.splitext(config.output)[0] + ".d2"
    write_text(d2_path, to_d2(graph, config.package, config.reverse))
    print(f"Диаграмма D2: {d2_path}")
    if render_svg_with_d2(d2_path, config.output):
        print(f"Изображение SVG (d2): {config.output}")
        return
    write_text(config.output,
               render_svg(graph, config.package, config.reverse))
    print(f"Изображение SVG (встроенный генератор): {config.output}")


def run(argv: List[str]) -> int:
    """Выполняет все этапы; ошибки приложения передаёт наверх."""
    config = parse_args(argv)
    validate_config(config)
    if config.show_config:
        print(format_config(config))
    index = load_dependency_index(config)
    source = reverse_index(index) if config.reverse else index
    graph = build_graph(source, config.package, config.max_depth)
    print(describe_graph(graph, config))
    print_dependencies(graph, config)
    save_visualization(graph, config)
    return EXIT_OK


def main(argv: Optional[List[str]] = None) -> int:
    """Запускает приложение и печатает понятное сообщение об ошибке."""
    try:
        return run(sys.argv[1:] if argv is None else argv)
    except DepGraphError as error:
        print(f"Ошибка: {error}", file=sys.stderr)
        return EXIT_ERROR
