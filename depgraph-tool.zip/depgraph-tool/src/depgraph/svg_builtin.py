"""Встроенный генератор SVG: запасной вариант, если утилиты d2 нет."""
from __future__ import annotations

from collections import deque
from typing import Dict, List, NamedTuple, Tuple
from xml.sax.saxutils import escape

from .graph import Graph, graph_edges

NODE_HEIGHT = 32
CHAR_WIDTH = 8
PAD_X = 14
GAP_X = 28
GAP_Y = 72
MARGIN = 24
LOOP_SIZE = 26
HALF = 2
ROOT_FILL = "#ffe9a8"
NODE_FILL = "#e8f0fe"
STROKE = "#4a5568"
EDGE_COLOR = "#718096"

Point = Tuple[float, float]


class Box(NamedTuple):
    """Прямоугольник узла: левый верхний угол и ширина."""

    x: float
    y: float
    width: float


def compute_levels(graph: Graph, root: str) -> List[List[str]]:
    """Раскладывает узлы по уровням (расстояние от корня), обход в ширину."""
    depth = {root: 0}
    levels = [[root]]
    queue = deque([root])
    while queue:
        name = queue.popleft()
        for dependency in graph.get(name, []):
            if dependency in depth:
                continue
            depth[dependency] = depth[name] + 1
            if depth[dependency] == len(levels):
                levels.append([])
            levels[depth[dependency]].append(dependency)
            queue.append(dependency)
    return levels


def node_width(name: str) -> float:
    """Ширина прямоугольника под подпись."""
    return len(name) * CHAR_WIDTH + PAD_X * HALF


def layout(levels: List[List[str]]) -> Tuple[Dict[str, Box], float, float]:
    """Вычисляет положение узлов и размер холста."""
    row_widths = [sum(node_width(name) for name in row)
                  + GAP_X * (len(row) - 1) for row in levels]
    canvas_width = max(row_widths) + MARGIN * HALF
    boxes: Dict[str, Box] = {}
    for row_number, (row, row_width) in enumerate(zip(levels, row_widths)):
        x = (canvas_width - row_width) / HALF
        y = MARGIN + row_number * (NODE_HEIGHT + GAP_Y)
        for name in row:
            boxes[name] = Box(x, y, node_width(name))
            x += node_width(name) + GAP_X
    rows = len(levels)
    canvas_height = (MARGIN * HALF + rows * NODE_HEIGHT
                     + (rows - 1) * GAP_Y)
    return boxes, canvas_width, canvas_height


def _anchors(source: Box, target: Box) -> Tuple[Point, Point]:
    """Выбирает точки соединения рёбер на границах узлов."""
    source_x = source.x + source.width / HALF
    target_x = target.x + target.width / HALF
    if target.y > source.y:
        return (source_x, source.y + NODE_HEIGHT), (target_x, target.y)
    if target.y < source.y:
        return (source_x, source.y), (target_x, target.y + NODE_HEIGHT)
    middle = source.y + NODE_HEIGHT / HALF
    if target.x > source.x:
        return (source.x + source.width, middle), (target.x, middle)
    return (source.x, middle), (target.x + target.width, middle)


def _loop_path(box: Box) -> str:
    """Путь петли для пакета, зависящего от самого себя."""
    x = box.x + box.width
    y = box.y + NODE_HEIGHT / HALF
    return (f"M {x:.1f} {y - 6:.1f} C {x + LOOP_SIZE:.1f} {y - LOOP_SIZE:.1f}"
            f" {x + LOOP_SIZE:.1f} {y + LOOP_SIZE:.1f} {x:.1f} {y + 6:.1f}")


def _edge_element(source: str, target: str, boxes: Dict[str, Box]) -> str:
    """SVG-элемент ребра со стрелкой."""
    if source == target:
        path = _loop_path(boxes[source])
    else:
        (x1, y1), (x2, y2) = _anchors(boxes[source], boxes[target])
        path = f"M {x1:.1f} {y1:.1f} L {x2:.1f} {y2:.1f}"
    return (f'<path d="{path}" fill="none" stroke="{EDGE_COLOR}" '
            'stroke-width="1.3" marker-end="url(#arrow)"/>')


def _node_element(name: str, box: Box, is_root: bool) -> str:
    """SVG-элементы узла: прямоугольник и подпись."""
    fill = ROOT_FILL if is_root else NODE_FILL
    center_x = box.x + box.width / HALF
    center_y = box.y + NODE_HEIGHT / HALF
    return (f'<rect x="{box.x:.1f}" y="{box.y:.1f}" width="{box.width:.1f}" '
            f'height="{NODE_HEIGHT}" rx="6" fill="{fill}" '
            f'stroke="{STROKE}"/>\n'
            f'<text x="{center_x:.1f}" y="{center_y:.1f}" '
            'text-anchor="middle" dominant-baseline="central" '
            f'font-family="monospace" font-size="13">{escape(name)}</text>')


def _header(width: float, height: float) -> str:
    """Начало документа SVG: размеры, стрелка и фон."""
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{width:.0f}" '
            f'height="{height:.0f}" viewBox="0 0 {width:.0f} {height:.0f}">\n'
            '<defs><marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" '
            'markerWidth="8" markerHeight="8" orient="auto">'
            f'<path d="M0 0 L10 5 L0 10 z" fill="{EDGE_COLOR}"/>'
            '</marker></defs>\n<rect width="100%" height="100%" '
            'fill="#ffffff"/>')


def render_svg(graph: Graph, root: str, flip: bool = False) -> str:
    """Рисует граф в виде SVG-документа."""
    boxes, width, height = layout(compute_levels(graph, root))
    parts = [_header(width, height)]
    for source, target in graph_edges(graph, flip):
        parts.append(_edge_element(source, target, boxes))
    for name, box in boxes.items():
        parts.append(_node_element(name, box, name == root))
    parts.append("</svg>")
    return "\n".join(parts) + "\n"
