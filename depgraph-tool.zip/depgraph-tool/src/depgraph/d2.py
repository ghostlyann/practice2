"""Текстовое представление графа на языке D2 и запуск утилиты d2."""
from __future__ import annotations

import shutil
import subprocess

from .graph import Graph, graph_edges

ROOT_FILL = "#ffe9a8"
D2_TIMEOUT = 120


def quote(name: str) -> str:
    """Заключает идентификатор в кавычки по правилам D2."""
    escaped = name.replace("\\", "\\\\").replace('"', '\\"')
    return f'"{escaped}"'


def to_d2(graph: Graph, root: str, flip: bool = False) -> str:
    """Формирует текст диаграммы D2; flip меняет направление стрелок."""
    lines = ["direction: down", ""]
    lines.append(f'{quote(root)}: {{style.fill: "{ROOT_FILL}"}}')
    lines.extend(quote(name) for name in graph if name != root)
    lines.append("")
    for source, target in graph_edges(graph, flip):
        lines.append(f"{quote(source)} -> {quote(target)}")
    return "\n".join(lines) + "\n"


def render_svg_with_d2(d2_path: str, svg_path: str) -> bool:
    """Строит SVG утилитой d2; False, если её нет или она упала."""
    executable = shutil.which("d2")
    if not executable:
        return False
    try:
        subprocess.run([executable, d2_path, svg_path], check=True,
                       capture_output=True, timeout=D2_TIMEOUT)
    except (OSError, subprocess.SubprocessError):
        return False
    return True
