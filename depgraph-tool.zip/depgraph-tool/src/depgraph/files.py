"""Запись результатов на диск."""
from __future__ import annotations

from .errors import OutputError


def write_text(path: str, text: str) -> None:
    """Записывает текст в файл UTF-8, ошибки превращает в OutputError."""
    try:
        with open(path, "w", encoding="utf-8") as handle:
            handle.write(text)
    except OSError as error:
        raise OutputError(f"не удалось записать {path}: {error}") from error
