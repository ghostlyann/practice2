"""Построение графа зависимостей: BFS без рекурсии, циклы, обратный граф."""
from __future__ import annotations

from collections import deque
from typing import Dict, List, Optional, Tuple

from .errors import PackageNotFoundError

Index = Dict[str, List[str]]
Graph = Dict[str, List[str]]


def build_graph(index: Index, root: str,
                max_depth: Optional[int] = None) -> Graph:
    """Строит граф достижимых из root пакетов обходом в ширину.

    Рекурсия не используется: обход идёт по очереди. Множество visited
    не даёт зациклиться, поэтому циклические зависимости безопасны, а
    ребро, замыкающее цикл, всё равно попадает в граф.
    """
    if root not in index:
        raise PackageNotFoundError(f"пакет '{root}' не найден в репозитории")
    graph: Graph = {}
    visited = {root}
    queue = deque([(root, 0)])
    while queue:
        name, depth = queue.popleft()
        if max_depth is not None and depth >= max_depth:
            graph[name] = []
            continue
        graph[name] = list(index.get(name, []))
        for dependency in graph[name]:
            if dependency not in visited:
                visited.add(dependency)
                queue.append((dependency, depth + 1))
    return graph


def reverse_index(index: Index) -> Index:
    """Строит индекс обратных зависимостей: пакет -> кто от него зависит."""
    reverse: Dict[str, List[str]] = {name: [] for name in index}
    for name, dependencies in index.items():
        for dependency in dependencies:
            reverse.setdefault(dependency, []).append(name)
    return {name: sorted(users) for name, users in reverse.items()}


def graph_edges(graph: Graph, flip: bool = False) -> List[Tuple[str, str]]:
    """Возвращает рёбра графа; flip меняет направление стрелок."""
    edges = []
    for name, dependencies in graph.items():
        for dependency in dependencies:
            edges.append((dependency, name) if flip else (name, dependency))
    return edges


def has_cycles(graph: Graph) -> bool:
    """Проверяет наличие цикла алгоритмом Кана (без рекурсии)."""
    incoming = {name: 0 for name in graph}
    for _, target in graph_edges(graph):
        incoming[target] += 1
    queue = deque(name for name, count in incoming.items() if not count)
    processed = 0
    while queue:
        name = queue.popleft()
        processed += 1
        for target in graph[name]:
            incoming[target] -= 1
            if not incoming[target]:
                queue.append(target)
    return processed < len(graph)
