"""Точка входа: python -m depgraph."""
import sys

from .cli import main

sys.exit(main())
