"""Чтение индекса пакетов Ubuntu (формат Packages) без внешних библиотек."""
from __future__ import annotations

import gzip
import lzma
import re
import urllib.error
import urllib.request
from typing import Dict, Iterator, List, Optional, Sequence

from .errors import RepositoryError
from .graph import Index

INDEX_NAMES = ("Packages.gz", "Packages.xz", "Packages")
WANTED_FIELDS = ("package", "depends", "pre-depends")
DEPENDENCY_FIELDS = ("pre-depends", "depends")
HTTP_TIMEOUT = 60
DECORATION_RE = re.compile(r"\([^)]*\)|\[[^\]]*\]|<[^>]*>")


def index_urls(base: str, release: str, components: Sequence[str],
               arch: str) -> List[str]:
    """Возвращает URL файлов Packages для заданного репозитория."""
    if base.endswith(INDEX_NAMES):
        return [base]
    root = base.rstrip("/")
    return [f"{root}/dists/{release}/{component}/binary-{arch}/Packages.gz"
            for component in components]


def download(url: str) -> bytes:
    """Скачивает файл по URL (http, https или file)."""
    try:
        with urllib.request.urlopen(url, timeout=HTTP_TIMEOUT) as response:
            return response.read()
    except (urllib.error.URLError, OSError, ValueError) as error:
        raise RepositoryError(f"не удалось загрузить {url}: {error}") from error


def decompress(data: bytes, url: str) -> str:
    """Распаковывает данные по расширению URL и декодирует в текст."""
    try:
        if url.endswith(".gz"):
            data = gzip.decompress(data)
        elif url.endswith(".xz"):
            data = lzma.decompress(data)
    except (OSError, EOFError, lzma.LZMAError) as error:
        raise RepositoryError(f"повреждён архив {url}: {error}") from error
    return data.decode("utf-8", errors="replace")


def clean_dependency(clause: str) -> str:
    """Оставляет имя первой альтернативы без версии и архитектуры."""
    first = clause.split("|")[0]
    without_marks = DECORATION_RE.sub("", first)
    return without_marks.strip().split(":")[0].strip()


def parse_dependency_field(value: str) -> List[str]:
    """Разбирает поле Depends: имена пакетов без повторов, по порядку."""
    names: List[str] = []
    for clause in value.split(","):
        name = clean_dependency(clause)
        if name and name not in names:
            names.append(name)
    return names


def _store_field(stanza: Dict[str, str], line: str) -> Optional[str]:
    """Сохраняет нужное поле строки; возвращает его ключ или None."""
    key, separator, value = line.partition(":")
    key = key.strip().lower()
    if not separator or key not in WANTED_FIELDS:
        return None
    stanza[key] = value.strip()
    return key


def iter_stanzas(text: str) -> Iterator[Dict[str, str]]:
    """Итерируется по записям файла Packages, храня только нужные поля."""
    stanza: Dict[str, str] = {}
    last_key: Optional[str] = None
    for line in text.splitlines():
        if not line.strip():
            if stanza:
                yield stanza
            stanza, last_key = {}, None
        elif line[0] in " \t":
            if last_key:
                stanza[last_key] += " " + line.strip()
        else:
            last_key = _store_field(stanza, line)
    if stanza:
        yield stanza


def _stanza_dependencies(stanza: Dict[str, str]) -> List[str]:
    """Собирает прямые зависимости записи (Pre-Depends и Depends)."""
    result: List[str] = []
    for field in DEPENDENCY_FIELDS:
        for name in parse_dependency_field(stanza.get(field, "")):
            if name not in result:
                result.append(name)
    return result


def parse_packages(text: str) -> Index:
    """Преобразует текст файла Packages в индекс пакет -> зависимости."""
    index: Index = {}
    for stanza in iter_stanzas(text):
        name = stanza.get("package")
        if name and name not in index:
            index[name] = _stanza_dependencies(stanza)
    return index


def load_index(base: str, release: str, components: Sequence[str],
               arch: str) -> Index:
    """Загружает и объединяет индексы всех указанных компонентов."""
    index: Index = {}
    for url in index_urls(base, release, components, arch):
        text = decompress(download(url), url)
        for name, dependencies in parse_packages(text).items():
            index.setdefault(name, dependencies)
    if not index:
        raise RepositoryError("в индексе репозитория нет ни одного пакета")
    return index
